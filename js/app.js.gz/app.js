﻿window.appFunctions = {
        selectElement: function(element, selectedId){
        element.selectedIndex = selectedId;
    }
}